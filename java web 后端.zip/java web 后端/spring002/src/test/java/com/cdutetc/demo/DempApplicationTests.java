package com.cdutetc.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DempApplicationTests {

	@Test
	void contextLoads() {
	}

}
