package com.cdutetc.demo.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="tbl_computer")
public class Computer {
    @Id
    private Long id;
    private String ip;
    
}
