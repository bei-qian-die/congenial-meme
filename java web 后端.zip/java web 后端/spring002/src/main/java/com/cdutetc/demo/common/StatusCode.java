package com.cdutetc.demo.common;

public enum StatusCode {
    SUCCESS(200,"操作成功"),
    UNAUTHORIZED(401,"访问未授权"),
    NOT_FOUND(404,"资源不存在"),
    BAD_REQUEST(400,"请求参数错误");
    StatusCode(int code,String msg){
        this.code=code;
        this.msg=msg;
    }
    private final int code;
    private final String msg;

    public int getCode(){
        return code;
    }
    public String getMsg(){
        return msg;
    }
    
}
