package com.cdutetc.demo.service;

import java.util.Optional;

import javax.management.RuntimeErrorException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cdutetc.demo.entity.User;
import com.cdutetc.demo.pojo.dto.UserRegister;
import com.cdutetc.demo.repository.UserRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class UserService {
    //自动装配
    private final UserRepository userRepository;

    public User createUser(UserRegister user){
        // User UserRegister
        User user1=new User();
        user1.setUsername(user.getUsername());
        user1.setPassword(user.getPassword());
        return userRepository.save(user1);
    }
    
    public User getUserById(Long id){
        return userRepository.findById(id).orElse(null);
    }

    public Optional<User> getUsersByUserName(String username){
        return userRepository.findByUsername(username);
    }


    
}
