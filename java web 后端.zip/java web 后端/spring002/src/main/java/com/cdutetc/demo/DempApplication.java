package com.cdutetc.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DempApplication {

	public static void main(String[] args) {
		SpringApplication.run(DempApplication.class, args);
	}

}
