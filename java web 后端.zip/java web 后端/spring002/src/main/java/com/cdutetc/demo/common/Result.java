package com.cdutetc.demo.common;

public class Result<T> {
    private int code;
    private String msg;
    private T data;
    private boolean success;

    private Result(boolean success,int code ,String msg,T data){
        this.success=success;
        this.code=code;
        this.msg=msg;
        this.data=data;
    }
    // 将多种返回情况，都创建出来，方便后续使用。
    // 成功，无数据
    public static <T> Result<T> success(){
        return new Result<>(true,StatusCode.SUCCESS.getCode(),StatusCode.SUCCESS.getMsg(),null);
    }
    // 成功，有数据
    public static <T> Result<T> success(T data){
        return new Result<>(true,StatusCode.SUCCESS.getCode(),StatusCode.SUCCESS.getMsg(),data);
    }
    // 失败，状态码
    public static <T> Result<T> success(StatusCode statusCode){
        return new Result<>(false,StatusCode.SUCCESS.getCode(),StatusCode.SUCCESS.getMsg(),null);
    }
    // 失败，自定义消息
    public static <T> Result<T> success(StatusCode statusCode,String msg){
        return new Result<>(false,StatusCode.SUCCESS.getCode(),msg,null);
    }
    // 失败 全部自定义
    public static <T> Result<T> success(int code ,String msg){
        return new Result<>(false,code,msg,null);
    }
    // 业务操作成功，特殊提示
    public static <T> Result<T> success(String msg){
        return new Result<>(true,StatusCode.SUCCESS.getCode(),msg,null);
    }
    // 成功，自定义消息
    public static <T> Result<T> success(T data,String msg){
        return new Result<>(true,StatusCode.SUCCESS.getCode(),msg,data);
    }



    
}
