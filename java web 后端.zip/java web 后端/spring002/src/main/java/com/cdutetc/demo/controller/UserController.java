package com.cdutetc.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cdutetc.demo.common.Result;
import com.cdutetc.demo.entity.User;
import com.cdutetc.demo.pojo.dto.UserRegister;
import com.cdutetc.demo.service.UserService;

import lombok.RequiredArgsConstructor;

// 一定会使用json进行数据返回，并且风格符合restful 要求
@RestController
@RequestMapping("/api/users")
@RequiredArgsConstructor
public class UserController {
    @Autowired
    private final UserService userService;

    @PostMapping
    public Result<User> createUser(@RequestBody UserRegister userRegister ){
        return Result.success(userService.createUser(userRegister));

    }



    
}
