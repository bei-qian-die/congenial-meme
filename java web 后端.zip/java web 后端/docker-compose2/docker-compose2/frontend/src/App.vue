<script setup>
import { ref } from 'vue';
import HelloWorld from './components/HelloWorld.vue'
import axios from 'axios';
const message=ref("")
const sayHi=async()=>{
  try {
    const response = await axios.get('/api/hello');
    message.value=response.data;
  } catch (error) {
    console.error('Error fetching data:', error);
    message.value="Error fetching data"
  }
}
</script>

<template>
  <div>
    <h1>{{ message }}</h1>
    <button @click="sayHi">sayHi</button>
  </div>
  <HelloWorld msg="Vite + Vue" />
</template>

<style scoped>
.logo {
  height: 6em;
  padding: 1.5em;
  will-change: filter;
  transition: filter 300ms;
}
.logo:hover {
  filter: drop-shadow(0 0 2em #646cffaa);
}
.logo.vue:hover {
  filter: drop-shadow(0 0 2em #42b883aa);
}
</style>
