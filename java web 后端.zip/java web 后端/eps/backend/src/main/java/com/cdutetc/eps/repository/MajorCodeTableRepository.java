package com.cdutetc.eps.repository;

import com.cdutetc.eps.entity.MajorCodeTable;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

// jpa 通过JpaRepository接口，来帮助我们实现数据库的基础操作(curd功能)
// 1 将当前的的repository变成一个接口
// 2 extends JpaRepository<需要处理的类,Long>
// 3 告诉spring ，当前这是一个repository（dao层）
@Repository
public interface MajorCodeTableRepository extends JpaRepository<MajorCodeTable,Long> {
    
}
