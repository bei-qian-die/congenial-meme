package com.cdutetc.eps.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

// @Entity 表示当前这个类，实际映射一张数据库表
@Entity
// 如果需要指定表的名称
@Table(name="tbl_mct")
@Data
public class MajorCodeTable {
    @Id
    // @GeneratedValue 增长值
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    //所属学院
    // @Column(name="ac")
    private String affiliatedCollege;
    //专业代码
    private String majorCode;
    //专业名称
    private String majorName;
    // 学制
    private String educationalSystem;
    //培养层次
    private String educationalLevel;
    
}
