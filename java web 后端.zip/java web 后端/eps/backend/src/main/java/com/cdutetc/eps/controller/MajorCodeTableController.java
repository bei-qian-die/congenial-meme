package com.cdutetc.eps.controller;

import java.util.List;

import com.cdutetc.eps.common.ApiResponse;
import com.cdutetc.eps.entity.MajorCodeTable;
import com.cdutetc.eps.repository.MajorCodeTableRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import lombok.RequiredArgsConstructor;

// controller 对外提供服务
// 1. 告诉spring，我可以提供哪些服务，服务的方式，
// @restcontroller 当前是一个controller，并且返回数据一定使用json类型、
// 2.路径：如何访问到当前的服务
// @RequsetMapping("/api/major-codes") 从端口开始，接受/api/major-codes 这样的路径打头请求
// 3. 准备一个dao层/service层的对象
// controller -> service(逻辑)->dao repository->entity->数据库
// 4. 使用@RequireArgsConstuctor 帮我们将全部 private final的对象，当做构造函数的参数，进行注入
// 5. 创建实际的函数（完成基础功能）
// restful 风格
// 无参数 get 表示获取全部数据
// pathverable get 表示获取指定数据
// json post 表示插入 @RequestBody
// pathverable delete 表示按指定参数删除

//1
@RestController
//2
@RequestMapping("/api/major-codes")
// 4 
@RequiredArgsConstructor
public class MajorCodeTableController {
    //3
    private final MajorCodeTableRepository majorCodeTableRepository;
    // 5 具体的功能

    @PostMapping
    public ApiResponse<MajorCodeTable> createMajorCode(@RequestBody MajorCodeTable majorCodeTable){
        //处理
        return ApiResponse.success(majorCodeTableRepository.save(majorCodeTable));
    }
    @GetMapping
    public ApiResponse<List<MajorCodeTable>> getAllMajorCode(){
        //处理
        return ApiResponse.success(majorCodeTableRepository.findAll());
    }


}
