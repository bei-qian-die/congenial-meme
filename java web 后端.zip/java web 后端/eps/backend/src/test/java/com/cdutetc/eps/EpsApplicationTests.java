package com.cdutetc.eps;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EpsApplicationTests {

	@Test
	void contextLoads() {
	}

}
