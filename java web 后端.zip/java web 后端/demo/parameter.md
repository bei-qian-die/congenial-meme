# 参数的传递

## URL 路径参数 前-》后

@PathVariable

## 查询参数
@RequestParam
比如分页查询


## 表单参数
@RequestParam

## JSON请求体
@RequestBody


## 文件上传

## header 参数

## 统一的参数传递方式
{
    success:,
    msg:,
    code:,
    data:,
}

## 分页查询

### 数据 

1. create
2. del
3. update
4. query

repository jps MyBatis-plus/MyBatis
