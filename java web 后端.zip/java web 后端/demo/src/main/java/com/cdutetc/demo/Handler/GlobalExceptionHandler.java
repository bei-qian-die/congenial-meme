package com.cdutetc.demo.Handler;

import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import com.cdutetc.demo.common.Result;
import com.cdutetc.demo.common.ResultCode;
import com.cdutetc.demo.common.BusinessException;

@RestControllerAdvice
public class GlobalExceptionHandler {
    // 捕获未预期的异常
    @ExceptionHandler(Exception.class)
    public Result<?> handleException(Exception e){
        return Result.fail(ResultCode.INTERNAL_SERVER_ERROR,e.getMessage());
    }
    // 业务异常
    @ExceptionHandler(BusinessException.class)
    public Result<?> handleBusinessException(BusinessException e){
        return Result.fail(e.getCode(),e.getMessage());
    }
    
}
