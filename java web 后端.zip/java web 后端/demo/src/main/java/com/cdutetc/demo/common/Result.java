
package com.cdutetc.demo.common;

// 该类用于构建系统的标准响应类
public class Result<T> {
    //状态码
    private int code;
    //是否成功
    private boolean success;
    //返回信息
    private String message;
    //返回数据
    private T data;

    public Result() {}

    public int getCode() {
        return code;
    }
    public void setCode(int code) {
        this.code = code;
    }
    public boolean isSuccess() {
        return success;
    }
    public void setSuccess(boolean success) {
        this.success = success;
    }
    public String getMessage() {
        return message;
    }
    public void setMessage(String message) {
        this.message = message;
    }
    public T getData() {
        return data;
    }
    public void setData(T data) {
        this.data = data;
    }

    //成功
    public static <T> Result<T> success(){
        return success(null);
    }
    public static <T> Result<T> success(T data){
        return success("操作成功",data);
    }

    public static <T> Result<T> success(String msg,T data){
    Result<T> result = new Result<>();
    result.setCode(200);
    result.setSuccess(true);
    result.setMessage(msg);
    result.setData(data);
    return result;

    }
    //失败
    public static <T> Result<T> fail(){
        return fail();
    }
    public static <T> Result<T> fail(String msg){
        return fail(msg);
    }
    
    public static <T> Result<T> fail(String msg,T data){
        Result<T> result = new Result<>();
        result.setCode(400);
        result.setSuccess(false);
        result.setMessage(msg);
        result.setData(data);
        return result;
    }
    public static <T> Result<T> fail(int code,String msg){
        return fail(code,msg);
    }

    public static <T> Result<T> fail(ResultCode code){
    return fail(code, null);
    }
    public static <T> Result<T> fail(ResultCode code, T data){
    Result<T> result = new Result<>();
    result.code = code.getCode();
    result.success = false;
    result.message = code.getMessage();
    result.data = data;
    return result;
    }




    
}
