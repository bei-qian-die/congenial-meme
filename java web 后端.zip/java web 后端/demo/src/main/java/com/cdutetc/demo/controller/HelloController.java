package com.cdutetc.demo.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
// 告诉spring，这是一个controller，可以对外提供服务
@RestController
public class HelloController {
    @Value("${app.name}")
    private String appName;
    // 可以通过请求/hello 的形式使用get请求方式，来使用下面的方法
    @GetMapping("/hello")
    public String sayHello(){
        return "Hello,"+appName+" Spring Boot!";
    }
    
}
