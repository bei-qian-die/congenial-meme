package com.cdutetc.demo.service;

import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import com.cdutetc.demo.repository.UserRepository;
import com.cdutetc.demo.common.PageResult;
import com.cdutetc.demo.common.Result;
import com.cdutetc.demo.model.ao.UserQueryAO;
import com.cdutetc.demo.model.vo.UserVO;

// 逻辑service 控制controller 数据repository 通用组件component
@Service
public class UserService {

    private final UserRepository userRepository;

    public Result<PageResult<UserVO>> queryUsers(UserQueryAO queryAO) {
        Sort sort =Sort.by(
            Sort.Direction.fromString(queryAO.getSortDirection() == null ? "ASC" : queryAO.getSortDirection()),
            queryAO.getSortField()
        );
        PageRequest pageable=PageRequest.of(queryAO.getPage(),queryAO.getSize(),sort);
        
    }
    
}
