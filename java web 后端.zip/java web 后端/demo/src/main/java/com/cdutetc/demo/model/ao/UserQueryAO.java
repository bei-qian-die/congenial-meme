package com.cdutetc.demo.model.ao;
import lombok.Data;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import org.hibernate.validator.constraints.Range;
@Data
public class UserQueryAO{
    @NotNull(message="页码不能为空")
    @Min(valus=0,message="页大小不能小于0")
    private Integer page=0;

    @NotNull(message="每页数量不能为空")
    @Range(min=1,max=100,message="每页数量在1-100")
    private Integer size=10;

}