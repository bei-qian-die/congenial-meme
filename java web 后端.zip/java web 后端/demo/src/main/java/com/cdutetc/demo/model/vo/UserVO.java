package com.cdutetc.demo.model.vo;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import com.cdutetc.demo.model.entity.User;
import lombok.Data;
@Data
public class UserVO {
    private Long id;
    private String username;
    private String email;
    private String nickname;
    private String createdAt;
    private String updatedAt;
    private String statusText;

    public static UserVO fromEntity(User user){
        UserVO vo = new UserVO();
        vo.setId(user.getId());
        vo.setUsername(user.getUsername());
        vo.setEmail(user.getEmail());
        vo.setNickname(user.getNickname());
        vo.setCreatedAt(formatDataTime(user.getCreateAt()));
        vo.setUpdatedAt(formatDataTime(user.getUpdatedAt()));
        vo.setStatusText(user.getStatus()==1?"正常":"禁用");
        return vo;
    }

    private static String formatDataTime(LocalDateTime dataTime){
        if(dataTime==null){
            return "";
        }
        return dataTime.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
    }
    
}
