package com.cdutetc.demo.model.entity;

import jakarta.persistence.Entity;

import java.time.LocalDateTime;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity //当前类是一个jpa的实体=数据库表
@Table(name="t_user")
@Data
@NoArgsConstructor
public class User {
    @Id // 标识主键
    @GeneratedValue(strategy = GenerationType.AUTO)  //主键自增
    private Long id;
    // name表示绑定表中的具体字段
    // nullable表示该字段是否可以为空
    // unique表示该字段是否唯一
    // length表示该字段的长度
    @Column(name="username",nullable=false,unique=true,length=50)
    private String username;

    @Column(name="password",nullable=false,length=100)
    private String password;

    @Column(name="email",unique = true,nullable = false,length=100)
    private String email;

    @Column(name="nickname",length=50)
    private String nickname;

    @Column(nullable = false)
    private Integer status=-1; //用户状态，0-禁用，1-正常，默认-1

    // 使用服务器自身时间戳
    @CreationTimestamp
    @Column(name="create_at",nullable = false)
    private LocalDateTime createAt;

    @UpdateTimestamp
    @Column(name="updated_at")
    private LocalDateTime updatedAt;

}
