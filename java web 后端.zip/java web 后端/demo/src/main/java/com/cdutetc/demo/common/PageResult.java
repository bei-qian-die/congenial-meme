package com.cdutetc.demo.common;

import lombok.Data;
import java.util.List;

import org.springframework.data.domain.Page;


@Data
public class PageResult<T> {
    private List<T> list;
    private int page;
    private int size;
    private long total;
    private int pages;

    public PageResult(Page<T> page){
        this.list=page.getContent();
        this.page=page.getNumber();
        this.size=page.getSize();
        this.total=page.getTotalElements();
        this.pages=page.getTotalPages();
    }
    public static <T> Result<PageResult<T>> success(Page<T> page){
        return Result.success(new PageResult<>(page));
    }
}
