package com.cdutetc.demo.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.*;

@Entity //当前类是一个jpa的实体=数据库表
@Table(name="t_user")
public class User {
    @Id // 标识主键
    @GeneratedValue(strategy = GenerationType.AUTO)  //主键自增
    private Long id;
    @Column(name="age")
    private Integer age;
    @Column(name="email")
    private String email;
    @Column(name="username")
    private String username;

    public User() {}

    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public Integer getAge() {
        return age;
    }
    public void setAge(Integer age) {
        this.age = age;
    }
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public String getUsername() {
        return username;
    }
    public void setUsername(String username) {
        this.username = username;
    }
}
