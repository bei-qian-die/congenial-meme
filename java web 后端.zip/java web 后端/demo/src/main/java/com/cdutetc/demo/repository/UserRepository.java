package com.cdutetc.demo.repository;
import org.springframework.data.jpa.repository.JpaRepository;

import com.cdutetc.demo.model.entity.User;

public interface UserRepository extends JpaRepository<User,Long>{
    
}
